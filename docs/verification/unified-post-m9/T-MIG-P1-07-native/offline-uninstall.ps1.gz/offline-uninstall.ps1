$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
if(@(Get-Process lintra-runtime-spike -ErrorAction SilentlyContinue).Count){throw 'Installed application still active'}
$rule=Get-NetFirewallRule -DisplayName 'Lintra-P1-07-20261114-Offline'
if($rule.Enabled -ne 'True' -or $rule.Direction -ne 'Outbound' -or $rule.Action -ne 'Block'){throw 'Offline rule inactive during uninstall'}
$paths=@('C:\Users\lintra-agent\AppData\Local\Lintra\Qualification-P1-07-20261114\synthetic-conservation.sqlite','C:\Users\lintra-agent\AppData\Local\Lintra\Qualification-P1-07-20261114\synthetic-config.txt')
$before=@{}; foreach($path in $paths){$before[$path]=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
$profiles=@('C:\Users\lintra-agent\AppData\Local\it.lintra.runtime-spike')
$complete=Get-Content 'C:\Users\lintra-agent\LintraQualification\P1-07-20261114\qualification-complete.json' -Raw|ConvertFrom-Json
if(-not $complete.passed -or $complete.installed_sha256 -ne (Get-FileHash 'C:\Program Files\Lintra Runtime Spike\lintra-runtime-spike.exe' -Algorithm SHA256).Hash.ToLowerInvariant()){throw 'Installed native qualification not complete or binary changed'}
$exe='C:\Program Files\Lintra Runtime Spike\uninstall.exe'
$p=Start-Process -FilePath $exe -ArgumentList '/S' -PassThru; $null=$p.Handle
if(-not $p.WaitForExit(120000)){Stop-Process -Id $p.Id -Force;throw 'Uninstaller launcher timed out'}
$launcherExit=$p.ExitCode; $deadline=[DateTime]::UtcNow.AddSeconds(60)
do{
 Start-Sleep -Seconds 1
 $installed=Test-Path -LiteralPath 'C:\Program Files\Lintra Runtime Spike\lintra-runtime-spike.exe'
 $registered=Test-Path -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Lintra Runtime Spike'
}until((-not $installed -and -not $registered) -or [DateTime]::UtcNow -ge $deadline)
$sentinels=foreach($path in $paths){$after=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant();[pscustomobject]@{path=$path; before=$before[$path]; after=$after; preserved=($before[$path] -eq $after)}}
$profileState=@($profiles | ForEach-Object {[pscustomobject]@{path=$_; preserved=(Test-Path -LiteralPath $_)}})
[ordered]@{offline_rule=($rule|Select-Object DisplayName,Enabled,Direction,Action);launcher_exit=$launcherExit; executable_removed=(-not $installed); hklm_metadata_removed=(-not $registered); installed_directory_remains=(Test-Path -LiteralPath 'C:\Program Files\Lintra Runtime Spike'); sentinels=$sentinels; webview_profiles=$profileState; scope='Synthetic conservation files and WebView profiles, not product persistence integration'} | ConvertTo-Json -Depth 5
if($launcherExit -ne 0 -or $installed -or $registered -or @($sentinels | Where-Object {-not $_.preserved}).Count -ne 0 -or @($profileState | Where-Object {-not $_.preserved}).Count -ne 0){throw 'Uninstall conservation failed'}
