$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$rule=Get-NetFirewallRule -DisplayName 'Lintra-P1-07-20261114-Offline'
$external=@('1.1.1.1','8.8.8.8') | ForEach-Object {
 $client=[Net.Sockets.TcpClient]::new(); $connected=$false; $failure=$null
 try {$async=$client.BeginConnect($_,443,$null,$null); $connected=$async.AsyncWaitHandle.WaitOne(2000) -and $client.Connected} catch {$failure=$_.Exception.InnerException.Message} finally{$client.Dispose()}
 [pscustomobject]@{address=$_; port=443; connected=$connected; error=$failure}
}
if(@($external | Where-Object connected).Count -ne 0){throw 'Internet still available; refuse offline claim'}
$root='C:\Users\lintra-agent\LintraQualification\P1-07-20261114'
$hash=(Get-FileHash -LiteralPath "$root\setup.exe" -Algorithm SHA256).Hash.ToLowerInvariant()
if($hash -ne 'b2bc84627e1286927b24e2ed79a00c77246bef334af14084cecbfd54ba1eedc1'){throw 'Installer hash mismatch'}
$runtimeBefore=@(Get-ChildItem -LiteralPath 'C:\Program Files (x86)\Microsoft\EdgeWebView\Application' -Directory | Select-Object -ExpandProperty Name)
$p=Start-Process -FilePath "$root\setup.exe" -ArgumentList '/S' -PassThru
$null=$p.Handle
if(-not $p.WaitForExit(300000)){Stop-Process -Id $p.Id -Force; throw 'NSIS timed out'}
$p.Refresh(); $exitCode=$p.ExitCode
$exe='C:\Program Files\Lintra Runtime Spike\lintra-runtime-spike.exe'
$entries=@(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue | Where-Object {$_.DisplayName -eq 'Lintra Runtime Spike'} | Select-Object PSPath,DisplayName,DisplayVersion,InstallLocation,UninstallString,QuietUninstallString)
[ordered]@{account=[Security.Principal.WindowsIdentity]::GetCurrent().Name; elevated=([Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator); offline_rule=($rule | Select-Object DisplayName,Enabled,Direction,Action); internet_probes=$external; installer_sha256=$hash; webview_before=$runtimeBefore; installer_exit=$exitCode; executable_exists=(Test-Path -LiteralPath $exe); executable_sha256=if(Test-Path -LiteralPath $exe){(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()}else{$null}; hklm_uninstall=$entries; services_added=@(Get-Service | Where-Object {$_.Name -match 'lintra'} | Select-Object Name,Status)} | ConvertTo-Json -Depth 6
if($exitCode -ne 0 -or -not(Test-Path -LiteralPath $exe) -or $entries.Count -ne 1){throw 'Machine installation acceptance failed'}
